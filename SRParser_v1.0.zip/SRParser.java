import java.util.*;
import java.io.File;
import java.io.IOException;


public class SRParser{

	private TreeMap<String, String[]> terminal, nonTerminal;
	private TreeMap<String, String> posTag;
	private ArrayList<TreeData> treeData;
	

	private Queue<String> srQueue;
	private Stack<String> stack;
	private ArrayList<String>[][]table;
	private String startSymbol;
	private File grammar;
	private Scanner scanner;
	private ArrayList<String> allGrammar;
    int MAX_SIZE_OF_QUEUE;
    static int ctr = 0;

    public  Tree<String> Pangngalan, Panghalip, Pandiwa, Panguri, Pantukoy, Simuno_payak, 
    					 Simuno_tambalan, Panaguri_payak,Panaguri_tambalan,Simuno,Pangawing,Panaguri,
    					 Pangatnig,Sugnay_dinakapagiisa,Sugnay_nakapagiisa, Kabalikang_ayos,Karaniwang_ayos,
    					 Pp_langkapan, Pp_hugnayan, Pp_tambalan, Pp_payak, Kayarian, Ayos, Pangungusap;


	public SRParser(){

		terminal = new TreeMap<String, String[]>();
		nonTerminal = new TreeMap<String, String[]>();
		treeData = new ArrayList<TreeData>();
		 	
	}

	public void readGrammarFile(String grammarFile){
		grammar = null;
		scanner = null;
		try{
			grammar = new File(grammarFile);
			scanner = new Scanner(grammar);

			String[] line = scanner.nextLine().replaceAll("\\s+","").split(":=");
			startSymbol = line[0];
		
			do{ 

				String[] rightHandSide = line[1].toString().split("!!");
				

				if(!line[1].contains("'"))
					nonTerminal.put(line[0], rightHandSide);
				else
					terminal.put(line[0], rightHandSide);
				


				if(scanner.hasNextLine()){
					line = scanner.nextLine().replaceAll("\\s+","").split(":=");
				}else{
					line = null;
				}
				
			}while(line != null);
			// System.out.println("Nonterminals: ");
				// for(String s: nonTerminal.keySet()){
		  //    		System.out.print("key: "+ s  + " value: " );

	   //       	 	for(String v: nonTerminal.get(s)){
	   //       			System.out.print(v +" ");
	   //        		}
	   //        		System.out.println();
	   //          }
	   //      	System.out.println("terminals: ");    
	   //     	    for(String s: terminal.keySet()){
				//   	System.out.print("key: "+ s  + " value: " );

	   //        		for(String v: terminal.get(s)){
	   //        			System.out.print(v +" ");
	   //        		}
	   //        		System.out.println();
	   //      	}

		}catch(Exception exeption){
			exeption.printStackTrace();
		}
		
	}
	public void processInput(String inputFile){
		
		try{
			scanner = new Scanner(new File(inputFile));
			srQueue = new LinkedList<String>();
			posTag = new TreeMap<String, String>();	
			stack = new Stack<String>();

			while(scanner.hasNextLine()){
				
				String[] line = scanner.nextLine().split("-");
				srQueue.add(line[0]);
				posTag.put(line[0], "<" +line[1].toLowerCase() + ">");

			}
			//MAX_SIZE_OF_QUEUE = srQueue.size();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public boolean shiftReduceParser(){
		System.out.println("INPUT SENTENCE: " + srQueue);
		try{
			//int x = 0;
			shift();
        	do{
	            decider();
	            if(stack.size() == 1 && stack.peek().equals(startSymbol)){
	            	stack.pop();
	            	System.out.println();
	            	System.out.println("*******The senctence is accepted. ././.*****");
	            }
           		//x++;
          	}while(!stack.isEmpty());

		        System.out.println("final_stack:" +stack);
		        System.out.println("final_queue:" + srQueue);
		        System.out.println();

		     //  System.out.println("Tree data: ");    
	      //  	    for(TreeData s: treeData){
				  	// System.out.print("parent: "+ s.parent  + " children: " );

	      //     		for(String v: s.children){
	      //     			System.out.print(v +" ");
	      //     		}
	      //     		System.out.println();
	      //   	}
	        	createTree();


		}catch(Exception e){
			e.printStackTrace();
		}

		return false;
		
	}
	public void decider(){
		boolean checker = lhsFinder();
		if(checker){	
           // System.out.println(stack.size());
		}else if(posTag.containsKey(stack.peek())){
			reduce(1, posTag.get(stack.peek()));
			//System.out.println(posTag.get(stack.peek()));
		}else{
			shift(); 	
		}
		
	}
	public void shift(){
		if(srQueue.size() != 0){
			stack.push(srQueue.poll());
			displayAction("shift");
		}
		
	}
	public void reduce(int numOfElements, String strToPush){
		ArrayList<String> arrTemp = new ArrayList<String>();
		TreeData  treeDataTemp = new TreeData();
                //ArrayList<String> arrTemp2 = new ArrayList<String>();

		for(int intLooper = 0; intLooper < numOfElements; intLooper++){
			arrTemp.add(stack.pop());
		}
		//System.out.println(numOfElements + "====" + strToPush);
		if(strToPush != null)
			stack.push(strToPush);

                //arrTemp2.add(arrTemp);
		treeDataTemp.parent = strToPush;
		treeDataTemp.children = arrTemp;     
		treeData.add(treeDataTemp);

        displayAction("reduce");
	}
	public boolean lhsFinder(){
		boolean flag = false;
		int intCtr;
		for(int intLooper = stack.size() - 1  ; intLooper > -1 ; intLooper--){
			intCtr = 0;
			String substring= "";
			for(int intLooper2 = intLooper; intLooper2  < stack.size()  ; intLooper2++, intCtr++){
				substring =  substring +"," + stack.get(intLooper2);
			}
			StringBuilder sb = new StringBuilder(substring);
			substring = sb.deleteCharAt(0).toString();

			for(String key: nonTerminal.keySet()){
				for(String value: nonTerminal.get(key)){
					if(substring.equals(value)){
						flag = true;
						reduce(intCtr, key);
						return flag;
					}
					
				}
				
			}
		}
		return flag;
	}
	public void displayAction(String action){

		System.out.println(stack + " || " + srQueue + "  [ " + action + " ]");

	}
	private void createTree(){
		//level6
		Pangngalan = new Tree<String>("<pangngalan>");
		Panghalip = new Tree<String>("<panghalip>");
		Pandiwa = new Tree<String>("<pandiwa>");
		Panguri = new Tree<String>("<panguri>"); 
		
		//level5
		 Pantukoy = new Tree<String>("<pantukoy>");
		 Simuno_payak = new Tree<String>("<simuno_payak>");
		Simuno_tambalan = new Tree<String>("<simuno_tambalan>");
		 Panaguri_payak = new Tree<String>("<panaguri_payak>"); 
		 Panaguri_tambalan = new Tree<String>("<panaguri_tambalan>");
	

		//level 4
		 Simuno = new Tree<String>("<simuno>");
		 Pangawing = new Tree<String>("<pangawing>");
		 Panaguri = new Tree<String>("<panaguri>");

		 Pangatnig = new Tree<String>("<pangatnig>");
		 Sugnay_dinakapagiisa = new Tree<String>("<sugnay_dinakapagiisa>");
		 Sugnay_nakapagiisa = new Tree<String>("<sugnay_nakapagiisa>");

		// level 3
		 Kabalikang_ayos = new Tree<String>("<kabalikang_ayos>");
		 Karaniwang_ayos = new Tree<String>("<karaniwang_ayos>");

		 Pp_langkapan = new Tree<String>("<pp_langkapan>");
		 Pp_hugnayan = new Tree<String>("<pp_hugnayan>");
		 Pp_tambalan = new Tree<String>("<pp_tambalan>");
		 Pp_payak = new Tree<String>("<pp_payak>");

		// level 2
		 Kayarian = new Tree<String>("<kayarian>");
		 Ayos = new Tree<String>("<ayos>");

		// level 1
		 Pangungusap = new Tree<String>("<pangungusap>");

		ArrayList<Tree<String>> arrTemp = new ArrayList<Tree<String>>();
		String rootChild = "";
		for(TreeData objTreeData: treeData){
		 	if(objTreeData.parent.equals(startSymbol)){
		 	   for(String child: objTreeData.children){
		 	   		rootChild = rootChild + child;
		 	   	   arrTemp.add(getTreeObject(child));

		 	   }
	 		}
	 	}

	 	fillTree(arrTemp); //recursively filling up the tree;
	 	
	 	Pangungusap.addChild(getTreeObject(rootChild));

		
		// MANUAL print
		// print root
	   // System.out.println(Pangungusap.getData());
		// S.getChildren().forEach( x->
		// 	System.out.println( "L " + x.getData() )
		// );

		// print level 2
		// S.getChildren().forEach( x-> 
		// 	x.getChildren().forEach( y->
		// 		System.out.println( "L L " + y.getData() ) 
		// 	)
		// );

		// print level 3
		// S.getChildren().forEach( x-> 
		// 	x.getChildren().forEach( y->
		// 		y.getChildren().forEach( z->
		// 			System.out.println( "L L L " + z.getData() ) 
		// 		)
		// 	)
		// );

		// PRINT USING BFS
		Pangungusap.goToChildren();
		

		
		new Scanner(System.in).nextLine();	 	
	
	}
	public  Tree<String> getTreeObject(String obj){
		switch(obj){
			case "<pangngalan>"			 : return Pangngalan;
			case "<panghalip>" 			 : return Panghalip;
			case "<pandiwa>"			 : return Pandiwa;
			case "<panguri>"			 : return Panguri;
			case "<pantukoy>"			 : return Pantukoy;
			case "<simuno_payak>"		 : return Simuno_payak;
			case "<simuno_tambalan>"	 : return Simuno_tambalan;
			case "<panaguri_payak>"		 : return Panaguri_payak;
			case "<panaguri_tambalan>"	 : return Panaguri_tambalan;
			case "<simuno>"				 : return Simuno;
			case "<pangawing>"			 : return Pangawing;
			case "<panaguri>"            : return Panaguri;
    		case "<pangatnig>"			 : return Pangatnig;
    		case "<sugnay_dinakapagiisa>": return Sugnay_dinakapagiisa;
    		case "<sugnay_nakapagiisa>"  : return Sugnay_nakapagiisa;
    		case "<kabalikang_ayos>"	 : return Kabalikang_ayos;
    		case "<karaniwang_ayos>"	 : return Karaniwang_ayos;
    		case "<pp_langkapan>"		 : return Pp_langkapan;
    		case "<pp_hugnayan>"		 : return Pp_hugnayan;
    		case "<pp_tambalan>"		 : return Pp_tambalan;
    		case "<pp_payak>"			 : return Pp_payak;
    		case "<kayarian>"			 : return Kayarian;
    		case "<ayos>"				 : return Ayos;
    		case "<pangungusap>"		 : return Pangungusap;
    		default						 : return null;
		}
		
	}
	public Tree<String> fillTree(ArrayList<Tree<String>> children){
		ArrayList<Tree<String>> arrTemp2 = new ArrayList<Tree<String>>();	
	   
		for(Tree<String> node: children){
			for(TreeData objTreeData: treeData){
				if(node.getData().equals(objTreeData.parent)){
					for(String child: objTreeData.children){
						if(child.contains("<")){
							node.addChild(getTreeObject(child));
							arrTemp2.add(getTreeObject(child));
						}else{
							node.addChild(child);
						}						
						//System.out.println("parent->"+ node.getData()+ " child->"+ child );
						//arrDelete.add(child);
						}
				}
			}
		}
	
		if(arrTemp2.size() == 0){
			//System.out.println("Done filling up the tree");
			return Pangungusap;
		}

		return fillTree(arrTemp2);
	}
	

}
class TreeData{
	public String parent;
	public ArrayList<String> children;
}