import java.util.*;

public class ParserMain{
	public static void main(String args[]){
		SRParser parser = new SRParser();
		parser.readGrammarFile("grammar-rules2.txt");
		parser.processInput("input.txt");
		parser.shiftReduceParser();
	}
}